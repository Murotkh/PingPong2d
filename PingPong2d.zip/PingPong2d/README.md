# Unity_PingPong_2D
A 2D Ping Pong game made in the Unity Engine.

When launching the project, click the "Scences" folder, and open the scene to access the game.
